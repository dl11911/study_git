create
    definer = root@localhost procedure boardWrite(IN id_val varchar(20), IN name_val varchar(40),
                                                  IN email_val varchar(40), IN subject_val varchar(255),
                                                  IN content_val varchar(4000))
BEGIN
  INSERT INTO board(id, name, email, subject, content, ref)
          VALUES(id_val, name_val, email_val, subject_val, content_val, 0);

    UPDATE BOARD SET REF = LAST_INSERT_ID() WHERE seq = last_insert_id();
END;

