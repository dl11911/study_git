create
    definer = root@localhost procedure boardDelete(IN seq_val bigint)
BEGIN
  update board set subject = concat('[원글이 삭제된 답글]' , subject) where pseq=seq_val;
    update BOARD set reply = reply - 1
    where seq = (select p.pseq from (select pseq from board where seq = seq_val) as p);
    delete from board where seq = seq_val;
END;

